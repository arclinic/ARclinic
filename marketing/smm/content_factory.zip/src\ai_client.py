import os
import requests
from typing import Dict, List

class AIClient:
    def __init__(self, api_key: str = None, base_url: str = None, model: str = 'qwen'):
        self.api_key = api_key or os.getenv('AI_API_KEY')
        self.base_url = base_url or os.getenv('AI_API_BASE_URL')
        
        if not self.api_key:
            raise ValueError("AI_API_KEY not set. Add it to .env file")
        if not self.base_url:
            raise ValueError("AI_API_BASE_URL not set. Add it to .env file")
        
        self.model = model
        
        if model == 'deepseek':
            self.model_name = 'deepseek-chat'
        elif model == 'qwen':
            self.model_name = 'qwen-max'
        else:
            self.model_name = model
    
    def generate(self, prompt: str, system_prompt: str = None, temperature: float = 0.7) -> str:
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        
        payload = {
            "model": self.model_name,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": 4096
        }
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        response = requests.post(
            f'{self.base_url}/chat/completions',
            headers=headers,
            json=payload
        )
        response.raise_for_status()
        
        return response.json()['choices'][0]['message']['content']
