import os
import requests
import time
from typing import List, Dict

ACTORS = {
    'x': 'apidojo/tweet-scraper-v2',
    'instagram': 'apify/instagram-scraper',
    'tiktok': 'clockworks/tiktok-scraper'
}

class ApifyClient:
    def __init__(self, token: str = None):
        self.token = token or os.getenv('APIFY_TOKEN')
        if not self.token:
            raise ValueError("APIFY_TOKEN not set. Add it to .env file")
        self.base_url = 'https://api.apify.com/v2'
    
    def fetch_posts(self, platform: str, accounts: List[str], max_posts: int = 50) -> List[Dict]:
        if platform not in ACTORS:
            raise ValueError(f"Platform {platform} not supported")
        
        actor_id = ACTORS[platform]
        
        if platform == 'x':
            input_data = {
                "searchTerms": accounts,
                "maxTweets": max_posts,
                "proxyConfig": {"useApifyProxy": True}
            }
        elif platform == 'instagram':
            input_data = {
                "searchInput": accounts,
                "maxPosts": max_posts,
                "proxyConfig": {"useApifyProxy": True}
            }
        elif platform == 'tiktok':
            input_data = {
                "searchQueries": accounts,
                "maxItems": max_posts,
                "proxyConfig": {"useApifyProxy": True}
            }
        
        response = requests.post(
            f'{self.base_url}/acts/{actor_id}/runs',
            params={'token': self.token},
            json=input_data
        )
        
        if response.status_code == 404:
            raise Exception(f"Apify actor '{actor_id}' not found. Check if actor name is correct.")
        elif response.status_code == 401:
            raise Exception("Invalid APIFY_TOKEN. Check your .env file.")
        
        response.raise_for_status()
        
        run_data = response.json()
        dataset_id = run_data['data']['defaultDatasetId']
        
        status = 'RUNNING'
        while status in ['RUNNING', 'READY']:
            time.sleep(5)
            status_response = requests.get(
                f'{self.base_url}/acts/{actor_id}/runs/{run_data["data"]["id"]}',
                params={'token': self.token}
            )
            status = status_response.json()['data']['status']
        
        if status != 'SUCCEEDED':
            raise Exception(f"Apify run failed with status: {status}")
        
        items_response = requests.get(
            f'{self.base_url}/datasets/{dataset_id}/items',
            params={'token': self.token}
        )
        
        return items_response.json()
